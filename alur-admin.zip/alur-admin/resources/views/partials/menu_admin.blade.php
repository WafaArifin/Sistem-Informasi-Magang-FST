<a href="{{ route('admin.ketentuan.index') }}" class="{{ request()->routeIs('admin.ketentuan.*') ? 'aktif' : '' }}">Ketentuan Magang</a>
<a href="{{ route('admin.tempat.index') }}" class="{{ request()->routeIs('admin.tempat.*') ? 'aktif' : '' }}">Tempat Magang</a>
<a href="{{ route('admin.surat.index') }}" class="{{ request()->routeIs('admin.surat.*') ? 'aktif' : '' }}">Surat Magang</a>
<a href="{{ route('admin.penempatan.index') }}" class="{{ request()->routeIs('admin.penempatan.*') ? 'aktif' : '' }}">Penempatan &amp; Jadwal</a>
<span class="nonaktif">Pengguna &amp; Role</span>
<span class="nonaktif">Data Mahasiswa</span>
<span class="nonaktif">Rekapitulasi</span>
