<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'SIM Magang') - SIM MAGANG</title>
    <style>
        :root { --biru:#12306b; --biru2:#1d4ed8; --abu:#f3f5f9; --teks:#1f2937; --garis:#e5e7eb; }
        * { box-sizing: border-box; }
        body { margin:0; font-family: "Segoe UI", Arial, sans-serif; background:var(--abu); color:var(--teks); }
        .layout { display:flex; min-height:100vh; }
        .sidebar { width:240px; background:var(--biru); color:#fff; padding:20px 16px; display:flex; flex-direction:column; }
        .sidebar h2 { font-size:18px; margin:0 0 4px; }
        .sidebar small { opacity:.75; }
        .sidebar nav { margin-top:24px; flex:1; }
        .sidebar a, .sidebar span.nonaktif { display:block; padding:10px 12px; border-radius:8px; color:#fff; text-decoration:none; font-size:14px; margin-bottom:4px; }
        .sidebar a.aktif, .sidebar a:hover { background:rgba(255,255,255,.18); }
        .sidebar span.nonaktif { opacity:.45; cursor:not-allowed; }
        .sidebar form button { width:100%; padding:10px; border:0; border-radius:8px; background:#dc2626; color:#fff; cursor:pointer; font-size:14px; }
        .konten { flex:1; padding:28px; }
        .atas { display:flex; justify-content:space-between; align-items:center; margin-bottom:22px; flex-wrap:wrap; gap:8px; }
        .atas h1 { margin:0; font-size:22px; }
        .peran { background:#e0e7ff; color:var(--biru); padding:4px 12px; border-radius:999px; font-size:13px; }
        .kartu-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(190px,1fr)); gap:16px; margin-bottom:24px; }
        .kartu { background:#fff; border:1px solid var(--garis); border-radius:12px; padding:18px; }
        .kartu .label { font-size:13px; color:#6b7280; }
        .kartu .angka { font-size:28px; font-weight:700; margin-top:6px; color:var(--biru); }
        .kartu .teks { font-size:17px; font-weight:600; margin-top:8px; }
        .panel { background:#fff; border:1px solid var(--garis); border-radius:12px; padding:18px; margin-bottom:20px; }
        .panel h3 { margin:0 0 12px; font-size:16px; }
        table { width:100%; border-collapse:collapse; font-size:14px; }
        th, td { text-align:left; padding:10px 8px; border-bottom:1px solid var(--garis); }
        th { color:#6b7280; font-weight:600; }
        .kosong { color:#6b7280; font-size:14px; padding:6px 0; }
        .badge { display:inline-block; padding:3px 10px; border-radius:999px; font-size:12px; font-weight:600; }
        .b-kuning { background:#fef3c7; color:#92400e; }
        .b-hijau  { background:#d1fae5; color:#065f46; }
        .b-merah  { background:#fee2e2; color:#991b1b; }
        .b-biru   { background:#dbeafe; color:#1e40af; }
        .b-abu    { background:#e5e7eb; color:#374151; }
        .info { background:#fff7ed; border:1px solid #fed7aa; color:#9a3412; padding:12px 14px; border-radius:10px; margin-bottom:18px; font-size:14px; }
        @media (max-width:760px){ .layout{flex-direction:column} .sidebar{width:100%} }
    </style>
</head>
<body>
<div class="layout">
    <aside class="sidebar">
        <h2>SIM MAGANG</h2>
        <small>Fakultas Sains dan Teknologi</small>
        <nav>
            <a href="{{ route('dashboard') }}" class="aktif">Dashboard</a>
            @yield('menu')
        </nav>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit">Logout</button>
        </form>
    </aside>

    <main class="konten">
        <div class="atas">
            <h1>@yield('judul')</h1>
            <div>
                {{ auth()->user()->nama_lengkap }}
                <span class="peran">{{ auth()->user()->role }}</span>
            </div>
        </div>
        @yield('isi')
    </main>
</div>
</body>
</html>
