@extends('layouts.app')
@section('title', 'Dashboard Akademik')
@section('judul', 'Dashboard Tim Akademik')

@section('menu')
    <span class="nonaktif">Pengguna &amp; Role</span>
    <span class="nonaktif">Data Mahasiswa</span>
    <span class="nonaktif">Tempat Magang</span>
    <span class="nonaktif">Surat Magang</span>
    <span class="nonaktif">Penempatan &amp; Jadwal</span>
    <span class="nonaktif">Rekapitulasi</span>
@endsection

@section('isi')
    <div class="kartu-grid">
        <div class="kartu">
            <div class="label">Total Dosen</div>
            <div class="angka">{{ $totalDosen }}</div>
        </div>
        <div class="kartu">
            <div class="label">Total Mahasiswa</div>
            <div class="angka">{{ $totalMahasiswa }}</div>
        </div>
        <div class="kartu">
            <div class="label">Pengajuan Masuk</div>
            <div class="angka">{{ $pengajuanMasuk }}</div>
        </div>
        <div class="kartu">
            <div class="label">Surat Diproses</div>
            <div class="angka">{{ $suratDiproses }}</div>
        </div>
    </div>

    <div class="panel">
        <h3>Pengajuan Terbaru</h3>
        @if ($pengajuanTerbaru->isEmpty())
            <div class="kosong">Belum ada pengajuan.</div>
        @else
            <table>
                <tr><th>Nama</th><th>NIM</th><th>Tempat Magang</th><th>Status</th></tr>
                @foreach ($pengajuanTerbaru as $p)
                    <tr>
                        <td>{{ $p->pendaftaran?->mahasiswa?->pengguna?->nama_lengkap }}</td>
                        <td>{{ $p->pendaftaran?->mahasiswa?->nim }}</td>
                        <td>{{ $p->tempat?->nama_instansi }}</td>
                        <td>@include('partials.badge', ['status' => $p->status_pengajuan])</td>
                    </tr>
                @endforeach
            </table>
        @endif
    </div>
@endsection
