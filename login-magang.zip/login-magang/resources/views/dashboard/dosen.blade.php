@extends('layouts.app')
@section('title', 'Dashboard Dosen')
@section('judul', 'Dashboard Dosen')

@section('menu')
    <span class="nonaktif">Verifikasi Pengajuan</span>
    <span class="nonaktif">Bimbingan</span>
    <span class="nonaktif">Laporan</span>
    <span class="nonaktif">Penilaian</span>
@endsection

@section('isi')
    @if (! $dosen)
        <div class="info">Profil dosen Anda belum dibuat oleh Tim Akademik. Hubungi administrator.</div>
    @endif

    <div class="kartu-grid">
        <div class="kartu">
            <div class="label">Mahasiswa PA</div>
            <div class="angka">{{ $mahasiswaPa }}</div>
        </div>
        <div class="kartu">
            <div class="label">Pengajuan Menunggu</div>
            <div class="angka">{{ $pengajuanMenunggu }}</div>
        </div>
        <div class="kartu">
            <div class="label">Mahasiswa Bimbingan Magang</div>
            <div class="angka">{{ $mahasiswaBimbingan }}</div>
        </div>
        <div class="kartu">
            <div class="label">Laporan Menunggu Diperiksa</div>
            <div class="angka">{{ $laporanMenunggu }}</div>
        </div>
    </div>

    <div class="panel">
        <h3>Pengajuan Terbaru</h3>
        @if ($pengajuanTerbaru->isEmpty())
            <div class="kosong">Belum ada pengajuan dari mahasiswa PA Anda.</div>
        @else
            <table>
                <tr><th>Nama</th><th>NIM</th><th>Tempat Magang</th><th>Status</th></tr>
                @foreach ($pengajuanTerbaru as $p)
                    <tr>
                        <td>{{ $p->pendaftaran?->mahasiswa?->pengguna?->nama_lengkap }}</td>
                        <td>{{ $p->pendaftaran?->mahasiswa?->nim }}</td>
                        <td>{{ $p->tempat?->nama_instansi }}</td>
                        <td>@include('partials.badge', ['status' => $p->status_pengajuan])</td>
                    </tr>
                @endforeach
            </table>
        @endif
    </div>
@endsection
